<font color="red"><?php echo validation_errors(); ?></font>
<?php echo form_open('LoginController/checklogin'); ?>

Username : <input type="text" name="username" />
<br>
Password : <input type="password" name="password" />
<br>
<input type="submit" name="submit" />
</form>

