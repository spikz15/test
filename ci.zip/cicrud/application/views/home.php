<html>
    <head>
        <title>Welcome User</title>
    </head>
    <body>
	<div align="right"> <a href="logout">Logout</a></div>
        <h1><?php echo "welcome user. You have logged in."; ?></h1>
    </body>
</html>