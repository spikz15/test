<html>
	<head>
		<title>Insert</title>
        <center><h1>Insert,Update,Delete</h1></center>
        <style type="text/css">
        .table1{
            padding: 2px;  

        }
             .input {
            padding: 2px; 
             border-radius: 2px;
            
        }
        </style>
    </head>
	
    <body>
		<form action=" <?php echo site_url('Student/insertdata'); ?>" method="post">
        	<center><table border="2" class="table1">
            	<tr>
                	<td>StudentName:</td>
					<td>
						<input type="text" name="name" class="input" />
                    </td>
                </tr>
                <tr>
                	<td>Email:</td>
					<td>
						<input type="text" name="email" class="input" />
                    </td>
                </tr>
                <tr>
                	<td>Phone:</td>
					<td>
						<input type="text" name="phone" class="input" />
                    </td>
                    
                </tr>
                <tr>
                	<td colspan="2">
                    	<center><input type="submit" value="submit" name="submit" /></center>
                    </td>
                </tr>
            </table></center>
            <center>
            <br>
            <table border="2" class="table1">
            <thead>
            	<th>ID</th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>PHONE</th>
                <th>ACTION</th>
                
            </thead>
            <tbody>
					<?php 
						foreach($this->StudentModel->viewdata() as $row)
						{
							echo "<tr>
								<td> $row->id </td>
								<td> $row->name </td>
								<td> $row->email </td>
								<td> $row->phone </td>
                                <td><a href='".site_url('Student/edit/'.$row->id)."'>Edit</a> | <a href='".site_url('Student/delete/'.$row->id)."'>Delete</a></td>
								</tr>";
                    
						}
					
					?>
            </tbody>
            </table></center>
        </form>
    </body>
</html>