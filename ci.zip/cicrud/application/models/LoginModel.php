<?php

class LoginModel extends CI_Model{
    
    public function login($name,$pass)
    {
        $this->db->select('username','password');
        $this->db->from('test3');
        $this->db->where('username',$name);
        $this->db->where('password',md5($pass));
        $query=$this->db->get();
        
        if($query->num_rows()==1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
}